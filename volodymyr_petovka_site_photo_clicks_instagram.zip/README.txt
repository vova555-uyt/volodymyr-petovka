Opravená verzia stránky.

Fotografia je vložená priamo do súboru index.html, takže sa zobrazí aj vtedy, keď otvoríš iba tento HTML súbor.
Kliknutie na fotografiu otvorí Instagram: https://www.instagram.com/vova_petovka/

Ak chceš stránku poslať vyučujúcemu cez internet, treba ju ešte zverejniť cez hosting, napríklad GitHub Pages.
